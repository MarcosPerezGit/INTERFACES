﻿namespace AgenciaViajes
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MenuDestinos = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuOfertas = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuReservas = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonDestinos = new System.Windows.Forms.Button();
            this.buttonOfertas = new System.Windows.Forms.Button();
            this.buttonReservas = new System.Windows.Forms.Button();
            this.buttonCerrar = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuDestinos,
            this.MenuOfertas,
            this.MenuReservas});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MenuDestinos
            // 
            this.MenuDestinos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.MenuDestinos.Name = "MenuDestinos";
            this.MenuDestinos.Size = new System.Drawing.Size(64, 20);
            this.MenuDestinos.Text = "Destinos";
            this.MenuDestinos.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // MenuOfertas
            // 
            this.MenuOfertas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.MenuOfertas.Name = "MenuOfertas";
            this.MenuOfertas.Size = new System.Drawing.Size(57, 20);
            this.MenuOfertas.Text = "Ofertas";
            this.MenuOfertas.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // MenuReservas
            // 
            this.MenuReservas.BackColor = System.Drawing.Color.Cyan;
            this.MenuReservas.Name = "MenuReservas";
            this.MenuReservas.Size = new System.Drawing.Size(64, 20);
            this.MenuReservas.Text = "Reservas";
            this.MenuReservas.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(259, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(264, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Agencia de Viajes 2025";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.pictureBox1.Location = new System.Drawing.Point(1, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(801, 50);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // buttonDestinos
            // 
            this.buttonDestinos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonDestinos.Location = new System.Drawing.Point(3, 3);
            this.buttonDestinos.Name = "buttonDestinos";
            this.buttonDestinos.Size = new System.Drawing.Size(203, 139);
            this.buttonDestinos.TabIndex = 3;
            this.buttonDestinos.Text = "Destinos";
            this.buttonDestinos.UseVisualStyleBackColor = false;
            this.buttonDestinos.Click += new System.EventHandler(this.buttonDestinos_Click);
            // 
            // buttonOfertas
            // 
            this.buttonOfertas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonOfertas.Location = new System.Drawing.Point(212, 3);
            this.buttonOfertas.Name = "buttonOfertas";
            this.buttonOfertas.Size = new System.Drawing.Size(204, 139);
            this.buttonOfertas.TabIndex = 4;
            this.buttonOfertas.Text = "Ofertas";
            this.buttonOfertas.UseVisualStyleBackColor = false;
            this.buttonOfertas.Click += new System.EventHandler(this.buttonOfertas_Click);
            // 
            // buttonReservas
            // 
            this.buttonReservas.BackColor = System.Drawing.Color.Cyan;
            this.buttonReservas.Location = new System.Drawing.Point(3, 148);
            this.buttonReservas.Name = "buttonReservas";
            this.buttonReservas.Size = new System.Drawing.Size(203, 140);
            this.buttonReservas.TabIndex = 5;
            this.buttonReservas.Text = "Reservas";
            this.buttonReservas.UseVisualStyleBackColor = false;
            this.buttonReservas.Click += new System.EventHandler(this.buttonReservas_Click);
            // 
            // buttonCerrar
            // 
            this.buttonCerrar.BackColor = System.Drawing.Color.Silver;
            this.buttonCerrar.Location = new System.Drawing.Point(212, 148);
            this.buttonCerrar.Name = "buttonCerrar";
            this.buttonCerrar.Size = new System.Drawing.Size(204, 140);
            this.buttonCerrar.TabIndex = 6;
            this.buttonCerrar.Text = "Cerrar";
            this.buttonCerrar.UseVisualStyleBackColor = false;
            this.buttonCerrar.Click += new System.EventHandler(this.buttonCerrar_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.buttonCerrar, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.buttonOfertas, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonReservas, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.buttonDestinos, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(183, 107);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(419, 291);
            this.tableLayoutPanel1.TabIndex = 7;
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormPrincipal";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MenuDestinos;
        private System.Windows.Forms.ToolStripMenuItem MenuOfertas;
        private System.Windows.Forms.ToolStripMenuItem MenuReservas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonDestinos;
        private System.Windows.Forms.Button buttonOfertas;
        private System.Windows.Forms.Button buttonReservas;
        private System.Windows.Forms.Button buttonCerrar;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}

