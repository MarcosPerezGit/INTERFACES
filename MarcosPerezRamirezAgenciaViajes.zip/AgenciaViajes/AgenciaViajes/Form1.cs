﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgenciaViajes
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormDestinos Destinos = new FormDestinos();
            Destinos.ShowDialog();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            FormOfertas Ofertas = new FormOfertas();
            Ofertas.ShowDialog();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            FormReservas Reservas = new FormReservas();
            Reservas.ShowDialog();
        }

        private void userControl11_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonDestinos_Click(object sender, EventArgs e)
        {
            FormDestinos Destinos = new FormDestinos();
            Destinos.ShowDialog();
        }

        private void buttonOfertas_Click(object sender, EventArgs e)
        {
            FormOfertas Ofertas = new FormOfertas();
            Ofertas.ShowDialog();
        }

        private void buttonReservas_Click(object sender, EventArgs e)
        {
            FormReservas Reservas = new FormReservas();
            Reservas.ShowDialog();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
